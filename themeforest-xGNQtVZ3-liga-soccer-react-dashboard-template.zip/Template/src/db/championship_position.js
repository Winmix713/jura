const championship_position = {
    0: [
        {team1: 4, team2: 18},
        {team1: 22, team2: 12},
        {team1: 2, team2: 8},
        {team1: 10, team2: 31},
        {team1: 7, team2: 22},
        {team1: 14, team2: 10},
        {team1: 19, team2: 2},
        {team1: 22, team2: 5},
        {team1: 15, team2: 10},
        {team1: 26, team2: 18},
    ],
    1: [
        {team1: 8, team2: 22},
        {team1: 10, team2: 26},
        {team1: 25, team2: 7},
        {team1: 14, team2: 11},
        {team1: 24, team2: 5},
        {team1: 5, team2: 16},
        {team1: 20, team2: 28},
        {team1: 4, team2: 5},
        {team1: 29, team2: 10},
        {team1: 10, team2: 18},
    ],
    2: [
        {team1: 18, team2: 5},
        {team1: 25, team2: 14},
        {team1: 4, team2: 19},
        {team1: 19, team2: 11},
        {team1: 5, team2: 7},
        {team1: 18, team2: 29},
        {team1: 4, team2: 2},
        {team1: 12, team2: 19},
        {team1: 2, team2: 22},
        {team1: 29, team2: 1},
    ]
}

export default championship_position