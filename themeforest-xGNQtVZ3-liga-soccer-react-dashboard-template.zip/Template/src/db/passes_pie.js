const passes_pie = {
    first: [
        { label: "shots", value: 18 },
        { label: "passes", value: 20 },
        { label: "crosses", value: 12 },
        { label: "saves", value: 6 },
        { label: "corners", value: 10 },
        { label: "outs", value: 28 }
    ],
    second: [
        { label: "shots", value: 25 },
        { label: "passes", value: 22 },
        { label: "crosses", value: 8 },
        { label: "saves", value: 9 },
        { label: "corners", value: 6 },
        { label: "outs", value: 18 }
    ]
}

export default passes_pie