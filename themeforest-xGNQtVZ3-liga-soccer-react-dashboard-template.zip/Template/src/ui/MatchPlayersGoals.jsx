// utils
import PropTypes from 'prop-types';

const MatchPlayersGoals = ({ data }) => {
    return (
        <div></div>
    )
}