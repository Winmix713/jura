const TODO_LEGEND = [
    {color: 'turquoise', text: 'Family'},
    {color: 'blue', text: 'Work'},
    {color: 'orange', text: 'Other'}
]

const TODO_OPTIONS = [
    {value: 'family', label: 'Family'},
    {value: 'work', label: 'Work'},
    {value: 'other', label: 'Other'}
]

export {TODO_LEGEND, TODO_OPTIONS}